

void loop() {
    int buttonState0 = digitalRead(buttonPin0);


    if (buttonState0 != previousButtonValue0) {
        if ((millis() - lastDebounceTime0) > debounceDelay) {
            //   knop 0 het antwoord '1' vertegenwoordigt
            if (buttonState0 == LOW) { //   de knop active LOW is
                // Publiceer het antwoord '1' naar het MQTT-topic
                client.publish("/mathgame/answer", "1");
                Serial.println("Answer 1 sent");
            }
            lastDebounceTime0 = millis();
        }
        previousButtonValue0 = buttonState0;
    }


}
