export class MathGame {
    constructor(numberOfStudents, numberOfQuestions) {
        this.numberOfStudents = numberOfStudents;
        this.numberOfQuestions = numberOfQuestions;
    }
}
