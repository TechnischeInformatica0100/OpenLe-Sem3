#include < ESP8266WiFi.h >
    #include < PubSubClient.h >
    #include < LiquidCrystal_I2C.h >

    // Initialiseren van de LCD
    LiquidCrystal_I2C lcd(0x27, 16, 2);


//   ESP8266 voor het Ontvangen en Weergeven van Rekensommen


const char* ssid = "";
const char* password = "";
const char* mqtt_server = "10.91.8.131";

WiFiClient espClient;
PubSubClient client(espClient);

void setup_wifi() {
    delay(10);
    // Verbind met wifi
    WiFi.begin(ssid, password);

    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
    }

    // Start de MQTT-verbinding
    client.setServer(mqtt_server, 1883);
    client.setCallback(callback);
}

void callback(char * topic, byte * payload, unsigned int length) {
    // Decodeer het MQTT-bericht
    payload[length] = '\0'; // Zorg voor een correcte string afsluiting
    String message = String((char *)payload);

    // Toon de rekensom op de LCD
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print(message);
}

void reconnect() {
    while (!client.connected()) {
        // MQTT reconnect logica
        if (client.connect("ESP8266Client")) {
            // Abonneer op het assignment topic
            client.subscribe("/mathgame/assignment");
        }
    }
}

void setup() {
    lcd.init(); // LCD initialisatie
    lcd.backlight();
    setup_wifi();
}

void loop() {
    if (!client.connected()) {
        reconnect();
    }
    client.loop();
}
